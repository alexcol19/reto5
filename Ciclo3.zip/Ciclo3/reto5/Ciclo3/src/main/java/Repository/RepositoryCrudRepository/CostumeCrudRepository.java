package Repository.RepositoryCrudRepository;

import Model.Costume;
import org.springframework.data.repository.CrudRepository;

public interface CostumeCrudRepository extends CrudRepository<Costume, Integer> {

}
